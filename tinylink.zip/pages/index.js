export default function Home() {
  return (<div>Dashboard Coming Soon</div>);
}