export default async function handler(req, res) {
  if (req.method === 'GET') return res.status(200).json({});
  if (req.method === 'DELETE') return res.status(200).json({ deleted:true });
}