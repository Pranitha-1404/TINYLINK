export default function CodeStats() {
  return (<div>Stats Page</div>);
}